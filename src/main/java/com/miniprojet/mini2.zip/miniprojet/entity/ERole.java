package com.miniprojet.miniprojet.entity;

public enum ERole {
    USER, ADMIN,ORGANISATEUR
}
