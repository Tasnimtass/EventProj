package com.miniprojet.miniprojet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiniprojetApplicationTests {

	@Test
	void contextLoads() {
	}

}
