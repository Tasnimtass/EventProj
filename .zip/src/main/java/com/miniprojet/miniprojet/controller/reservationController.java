package com.miniprojet.miniprojet.controller;

import com.miniprojet.miniprojet.entity.Reservation;
import com.miniprojet.miniprojet.repository.reservationRepository;
import com.miniprojet.miniprojet.service.EvenementService;
import com.miniprojet.miniprojet.service.UtilisateurService;
import com.miniprojet.miniprojet.service.reservationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/reservations")
public class reservationController {
    @Autowired
    private reservationService resSer;

    @Autowired
    private UtilisateurService userSer;

    @Autowired
    private EvenementService eventSer;

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/get-reservations")
    public ResponseEntity<List<Reservation>> getRes(){
        try{
            List<Reservation> reservationlist =resSer.getReservations();
            if(reservationlist.isEmpty()){
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<>(reservationlist,HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/get-reservation-by-id/{id}")
    public ResponseEntity<Reservation> getReservationById(@PathVariable Integer id){
        Optional<Reservation> reservation=resSer.getReservationById(id);
        if(reservation.isPresent()){
            return new ResponseEntity<>(reservation.get(),HttpStatus.OK);
        }
        else{
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/update-reservation/{id}")
    public ResponseEntity<Reservation> updateReservation(@PathVariable Integer id , @RequestBody Reservation reservation){
        Reservation updateReservation =resSer.updateReservation(id,reservation);
        if(reservation!=null){
            return new ResponseEntity<>(updateReservation,HttpStatus.OK);
        }
        else{
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PreAuthorize("isAuthenticated()")
    @PostMapping("/create-reservation/{idUser}/{idEvent}")
    public ResponseEntity<?> createReservation(
            @RequestBody Reservation reservation,
            @PathVariable Integer idUser,
            @PathVariable Integer idEvent) {
        try {
            Reservation savedReservation = resSer.createReservation(reservation, idUser, idEvent);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedReservation);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }

    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/delete-reservation/{id}")
    public ResponseEntity<HttpStatus> deleteReservation(@PathVariable Integer id){
        resSer.deleteReservation(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }


}
