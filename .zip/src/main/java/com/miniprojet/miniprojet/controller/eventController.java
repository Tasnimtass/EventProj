package com.miniprojet.miniprojet.controller;

import com.miniprojet.miniprojet.entity.Evenement;
import com.miniprojet.miniprojet.entity.Utilisateur;
import com.miniprojet.miniprojet.service.EvenementService;
import com.miniprojet.miniprojet.service.UtilisateurService;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/events")
public class eventController {

    @Autowired
    private EvenementService eventSer;

    @Autowired
    private UtilisateurService userSer;

    @GetMapping("/get-events")
    public ResponseEntity<List<Evenement>> getEvents(){
        try{
            List<Evenement> eventlist =eventSer.getEvents();
            if(eventlist.isEmpty()){
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);

            }
            return new ResponseEntity<>(eventlist, HttpStatus.OK);

        }catch (Exception ex){
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/get-event-by-id/{id}")
    public ResponseEntity<Evenement> getEventById(@PathVariable Integer id){
        Optional<Evenement> event=eventSer.getEventById(id);
        if(event.isPresent()){
            return new ResponseEntity<>(event.get(),HttpStatus.OK);
        }
        else{
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PreAuthorize("hasRole('ORGANISATEUR')")
    @PutMapping("/update-event/{id}")
    public ResponseEntity<Evenement> updateEvent(@PathVariable Integer id , @RequestBody Evenement event){
        Evenement updateEvent =eventSer.updateEvent(id,event);
        if(event!=null){
            return new ResponseEntity<>(updateEvent,HttpStatus.OK);
        }
        else{
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PreAuthorize("hasRole('ORGANISATEUR')")
    @PostMapping("/create-event/{id}")
    public ResponseEntity<Evenement> createEvent(@RequestBody Evenement event, @PathVariable Integer id) {
        try {
            Evenement savedEvent = eventSer.createEvent(event, id);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedEvent);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }

    @PreAuthorize("hasRole('ORGANISATEUR')")
    @DeleteMapping("/delete-event/{id}")
    public ResponseEntity<HttpStatus> deleteEvent(@PathVariable Integer id){
        eventSer.deleteEvent(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }



}
