package com.miniprojet.miniprojet.controller;

import com.miniprojet.miniprojet.config.JwtUtils;
import com.miniprojet.miniprojet.entity.ERole;
import com.miniprojet.miniprojet.entity.Utilisateur;
import com.miniprojet.miniprojet.service.UtilisateurService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/users")
public class UtilisateurController {

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtUtils jwtUtils;

    @Autowired
    private UtilisateurService userService;

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/get-users")
    public ResponseEntity<List<Utilisateur>> getUsers(){
        try{
            List<Utilisateur> userlist =userService.getUsers();
            if(userlist.isEmpty()){
               return  new ResponseEntity<>(userlist,HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<>(userlist,HttpStatus.OK);
        }catch(Exception ex){
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PreAuthorize("#id == authentication.principal.id or hasRole('ADMIN')")
    @GetMapping("/get-user-by-id/{id}")
    public ResponseEntity<Utilisateur> getUserById(@PathVariable Integer id){

            Optional<Utilisateur> user=userService.getUserById(id);
            if(user.isPresent()){
                return new ResponseEntity<>(user.get(),HttpStatus.OK);
            }
            else{
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
    }

    @PostMapping("/connexion")
    public ResponseEntity<?> getUserByEmail(@RequestBody Utilisateur utilisateur) {
        Utilisateur user = userService.getUser(utilisateur.getEmail());
        if (user == null) {
            return ResponseEntity.status(401).body("Utilisateur non trouvé");
        }

        // Ajout d'un log pour afficher les emails et les comparaisons
        System.out.println("Utilisateur trouvé : " + user.getEmail());
        System.out.println("Mot de passe envoyé : " + utilisateur.getMdp());
        System.out.println("Mot de passe en base : " + user.getMdp());

        if (!passwordEncoder.matches(utilisateur.getMdp(), user.getMdp())) {
            return ResponseEntity.status(401).body("Mot de passe incorrect");
        }

        String token = jwtUtils.generateToken(user.getEmail());
        return ResponseEntity.ok(new AuthResponse(token));
    }


    static class AuthResponse {
        private String token;

        public AuthResponse(String token) {
            this.token = token;
        }

        public String getToken() {
            return token;
        }

        public void setToken(String token) {
            this.token = token;
        }
    }

    @PostMapping("/create-user")
    public  ResponseEntity<?> createUser(@Valid @RequestBody Utilisateur user, BindingResult bindingResult){
        if (bindingResult.hasErrors()) {
            return ResponseEntity.badRequest().body(bindingResult.getAllErrors());
        }
        userService.createUser(user);
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body("Utilisateur créé avec succès !");
    }

    @PutMapping("/update-user/{id}")
    public ResponseEntity<Utilisateur> updateUser(@PathVariable Integer id , @RequestBody Utilisateur User){
        Utilisateur NewUser =userService.updateUser(id,User);
        if(User!=null){
            return new ResponseEntity<>(NewUser,HttpStatus.OK);
        }
        else{
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/delete-user/{id}")
    public ResponseEntity<HttpStatus> deleteUser(@PathVariable Integer id){
        userService.deleteUser(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/set-admin/{id}")
    public ResponseEntity<?> makeAdmin(@PathVariable Integer id) {
        userService.assignAdminRole(id);
        return ResponseEntity.ok("Rôle ADMIN attribué au compte");
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/assign-role/{userId}/{roleName}")
    public ResponseEntity<?> assignRole(@PathVariable Integer userId, @PathVariable ERole roleName) {
        userService.assignRole(userId, roleName);
        return ResponseEntity.ok("Rôle " + roleName + " attribué avec succès !");
    }
}
