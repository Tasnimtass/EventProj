package com.miniprojet.miniprojet.service;

import com.miniprojet.miniprojet.entity.Evenement;
import com.miniprojet.miniprojet.entity.Reservation;
import com.miniprojet.miniprojet.entity.Utilisateur;
import com.miniprojet.miniprojet.repository.reservationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class reservationService {

    @Autowired
    private reservationRepository resRep;

    @Autowired
    private UtilisateurService userSer;

    @Autowired
    private EvenementService eventSer;

    public Optional<Reservation> getReservationById(Integer id){
        return resRep.findById(id);
    }
    public List<Reservation> getReservations(){
        return resRep.findAll();
    }
    public void deleteReservation(Integer id){
        resRep.deleteById(id);
    }

    public Reservation createReservation(Reservation reservation, Integer idUser, Integer idEvent) {
        Optional<Utilisateur> user = userSer.getUserById(idUser);
        Optional<Evenement> event = eventSer.getEventById(idEvent);

        if (user.isEmpty() || event.isEmpty()) {
            throw new RuntimeException("Utilisateur ou événement avec cet ID n'existe pas.");
        }

        // Vérifier nombre de places
        if (reservation.getNbrPlaces() > event.get().getPlacesDisp() || reservation.getNbrPlaces() < 1) {
            event.get().setPlacesDisp(event.get().getPlacesDisp() - reservation.getNbrPlaces());
            throw new RuntimeException("Nombre de places invalide (disponibles: " + event.get().getPlacesDisp() + ")");
        }

        // Affecter utilisateur + événement à la réservation
        reservation.setUser(user.get());
        reservation.setEvenement(event.get());

        return resRep.save(reservation);
    }

    public Reservation updateReservation(Integer id, Reservation newReservation) {
        Optional<Reservation> oldReservation = resRep.findById(id);

        if (oldReservation.isPresent()) {
            Reservation updateReservation = oldReservation.get();
            Evenement evenement = updateReservation.getEvenement();
            if (newReservation.getNbrPlaces() <= evenement.getPlacesDisp()) {

                updateReservation.setNbrPlaces(newReservation.getNbrPlaces());
                updateReservation.setDateRes(newReservation.getDateRes());
                evenement.setPlacesDisp(evenement.getPlacesDisp() - newReservation.getNbrPlaces());

                resRep.save(updateReservation);
                eventSer.updateEvent(evenement.getId(),evenement);  // Mise à jour de l'événement avec le nouveau nombre de places disponibles

                return updateReservation;
            } else {
                // Si le nombre de places demandées dépasse les places disponibles
                throw new RuntimeException("Nombre de places demandé dépasse les places disponibles dans l'événement.");
            }
        } else {
            // Si la réservation n'existe pas
            return null;
        }
    }

}
