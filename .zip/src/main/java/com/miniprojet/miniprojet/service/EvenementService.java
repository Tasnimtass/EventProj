package com.miniprojet.miniprojet.service;

import com.miniprojet.miniprojet.entity.Evenement;
import com.miniprojet.miniprojet.entity.Utilisateur;
import com.miniprojet.miniprojet.repository.eventRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EvenementService {
    @Autowired
    private eventRepository evRep;

    @Autowired
    private UtilisateurService userSer;

    public List<Evenement> getEvents(){
        return evRep.findAll();
    }

    public Optional<Evenement> getEventById(Integer id){
        return evRep.findById(id);
    }

    public Evenement createEvent(Evenement event, Integer userID) {
        Optional<Utilisateur> organisateurOpt = userSer.getUserById(userID);
        if (organisateurOpt.isPresent()) {
            event.setOrganisateur(organisateurOpt.get());
            return evRep.save(event);
        } else {
            throw new RuntimeException("Organisateur avec ID " + userID + " non trouvé");
        }
    }

    public void deleteEvent(Integer id){
        evRep.deleteById(id);
    }

    public Evenement updateEvent(Integer id,Evenement newEvent){
        Optional<Evenement> oldEvent =evRep.findById(id);
        if(oldEvent.isPresent()){
            Evenement updateEvent =oldEvent.get();
            updateEvent.setTitre(newEvent.getTitre());
            updateEvent.setDate(newEvent.getDate());
            updateEvent.setPlacesDisp(newEvent.getPlacesDisp());
            updateEvent.setLieu(newEvent.getLieu());
            updateEvent.setDescription(newEvent.getDescription());
            return evRep.save(updateEvent);

        }
        else{
            return null;
        }
    }
}
