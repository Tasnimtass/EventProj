package com.miniprojet.miniprojet.repository;

import com.miniprojet.miniprojet.entity.Reservation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface reservationRepository extends JpaRepository<Reservation,Integer> {
}
